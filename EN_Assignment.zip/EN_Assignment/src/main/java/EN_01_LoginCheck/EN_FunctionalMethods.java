package EN_01_LoginCheck;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class EN_FunctionalMethods {
    private final WebDriver driver;
    public EN_FunctionalMethods (WebDriver driver){
        this.driver=driver;
    }
    public void click(By locator){
        driver.findElement(locator).click();
    }
    public void sendText(By locator, String text){
        driver.findElement(locator).sendKeys(text);
    }
    public String getText(By locator){
        return driver.findElement(locator).getText();
    }
    public WebElement waitForElementVisible (By locator, int time){
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(time));
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }
    public boolean isElementVisible (By locator, int time){
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(time));
        try{
            WebElement Ele= wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
            return Ele.isDisplayed();
        }catch(Exception e){
            return false;
        }
    }
    public WebElement waitForElementClickable (By locator, int time){
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(time));
        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }
    public void enterEmailOnLoginPage(String Email){
        click(Locators.emailFieldOnLoginPage);
        sendText(Locators.emailFieldOnLoginPage, Email);
    }
    public void enterPasswordOnLoginPage(String Password){
        click(Locators.passwordFieldOnLoginPage);
        sendText(Locators.passwordFieldOnLoginPage, Password);
    }
    public void ClickLogInOnLogInPage(){
        click(Locators.LogInOnLoginPage);
    }
    public void ClickSignUpOnLogInPage(){
        click(Locators.SignUpOnLoginPage);
    }
    public void enterEmailOnSignUpPage(String Email){
        click(Locators.emailFieldOnSignUpPage);
        sendText(Locators.emailFieldOnSignUpPage, Email);
    }
    public void checktermsOnSignUpPage(){
        click(Locators.termsCheckboxOnSignUpPage);
    }
    public void clickProceedOnSignUpPage(){
        click(Locators.proceedOnSignUpPage);
    }
    public void SignInValidation(String Email, String Password){
        click(Locators.emailFieldOnLoginPage);
        sendText(Locators.emailFieldOnLoginPage, Email);
        click(Locators.passwordFieldOnLoginPage);
        sendText(Locators.passwordFieldOnLoginPage, Password);
        ClickLogInOnLogInPage();
        if (isElementVisible(Locators.errorEnterValidEmail, 5)){
            String ErrorEnterValidPassword= getText(Locators.errorEnterValidEmail);
            System.out.println(ErrorEnterValidPassword);
        }else if (isElementVisible(Locators.errorEnterEmail, 5)) {
            String ErrorEnterEmail = getText(Locators.errorEnterEmail);
            System.out.println(ErrorEnterEmail);
        }else if (isElementVisible(Locators.errorEnterPassword, 5)) {
            String ErrorEnterpassword = getText(Locators.errorEnterPassword);
            System.out.println(ErrorEnterpassword);
        }
    }

    public void SignUpPageValidation_TermsError(String Email){
        click(Locators.SignUpOnLoginPage);
        click(Locators.emailFieldOnSignUpPage);
        sendText(Locators.emailFieldOnSignUpPage, Email);
        click(Locators.proceedOnSignUpPage);
        if (isElementVisible(Locators.errorchecktermsOnSignUpPage, 5)){//Please agree to the terms and conditions
            String ErrorCheckTerms= getText(Locators.errorchecktermsOnSignUpPage);
            System.out.println(ErrorCheckTerms);
        }if (isElementVisible(Locators.errorEnterValidEmailOnSignUpPage, 5)){//Please enter a valid email
            String ErrorCheckTerms= getText(Locators.errorEnterValidEmailOnSignUpPage);
            System.out.println(ErrorCheckTerms);
        }if (isElementVisible(Locators.errorEnterEmailOnSignUpPage, 5)){//Please enter email
            String ErrorCheckTerms= getText(Locators.errorEnterEmailOnSignUpPage);
            System.out.println(ErrorCheckTerms);
        }
    }

    public void SignUpPageValidation(String Email){
        ClickSignUpOnLogInPage();
        enterEmailOnSignUpPage(Email);
        checktermsOnSignUpPage();
        clickProceedOnSignUpPage();
        if (isElementVisible(Locators.errorEnterEmailOnSignUpPage, 5)){ //for blank email
            String ErrorEnterEmailSignUpPage= getText(Locators.errorEnterEmailOnSignUpPage);
            System.out.println(ErrorEnterEmailSignUpPage);
        }else if (isElementVisible(Locators.errorEnterValidEmailOnSignUpPage, 5)) {//for invalid email
            String ErrorEnterValidEmail = getText(Locators.errorEnterValidEmailOnSignUpPage);
            System.out.println(ErrorEnterValidEmail);
        }
    }
    public void ForgetPasswordOnLogInPage(String Email){
        click(Locators.forgetPasswordOnLoginPage);
        click(Locators.emailFieldOnforgetPasswordPage);
        sendText(Locators.emailFieldOnforgetPasswordPage, Email);
        click(Locators.proceedOnforgetPasswordPage);
        if (isElementVisible(Locators.errorEnterValidEmailOnforgetPasswordPage, 5)){//Please enter a valid email
            String ErrorEnterValidPassword= getText(Locators.errorEnterValidEmailOnforgetPasswordPage);
            System.out.println(ErrorEnterValidPassword);
        }else if (isElementVisible(Locators.errorEnterEmailOnforgetPasswordPage, 5)) {//Please enter email--for blank email
            String ErrorEnterEmail = getText(Locators.errorEnterEmailOnforgetPasswordPage);
            System.out.println(ErrorEnterEmail);
        }
    }
}
