package EN_01_LoginCheck;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class GetDriverHere {
    private static WebDriver driver;
    public static WebDriver initDriver() {
        if(driver==null) {
            //Initializing the driver
            System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver-win64\\chromedriver.exe"); // Replace with your chromedriver path
            ChromeOptions cop = new ChromeOptions();
            cop.addArguments("--remote-allow-origins=*");
            driver = new ChromeDriver(cop);
            driver.manage().window().maximize();
        }
            return driver;
        }
    public static void quitdriver(){
        if(driver!=null){
            driver.quit();
        }
    }
}
