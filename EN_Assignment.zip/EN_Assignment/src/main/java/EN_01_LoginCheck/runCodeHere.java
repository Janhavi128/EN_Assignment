package EN_01_LoginCheck;
// BDD approach also can be used for this testing. we can have each method as each test case.
import org.openqa.selenium.*;
public class runCodeHere{

    public static void main(String[] args) {
        WebDriver driver = GetDriverHere.initDriver();
        EN_FunctionalMethods use =new EN_FunctionalMethods(driver);
        //launch browser
        driver.get("https://app-staging.nokodr.com/super/apps/auth/v1/index.html");

        //Sign in page validations
        //email & password inputs = "abc"-- check variation - valid mail, password/ blank mail,password
//        use.SignInValidation("abc","abc");

        //Uncomment below line for Signup page validation without checking terms
        // email input = "abc" -- check variation - valid mail/ blank mail
//        use.SignUpPageValidation_TermsError("abc");

        //Uncomment below line for Signup page validation by checking terms
        // email input = "abc" -- check variation - valid mail/ blank mail
//        use.SignUpPageValidation("abc");

        //Uncomment below line for forget password validation by checking terms
        // email input = "abc" -- check variation - valid mail/ blank mail
        use.ForgetPasswordOnLogInPage("abc");

    }
}






