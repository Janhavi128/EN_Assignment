package EN_01_LoginCheck;

import org.openqa.selenium.By;

public class Locators{
    //Login Page locators
    public static By emailFieldOnLoginPage = By.xpath("//input[@type='email']");
    public static By passwordFieldOnLoginPage =By.xpath("//input[@type='password']");
    public static By SignUpOnLoginPage =By.xpath("//a[text()='Sign up']");
    public static By forgetPasswordOnLoginPage =By.xpath("//a[text()='Forgot Password?']");
    public static By errorEnterEmail =By.xpath("//h2[text()='Please enter email']");
    public static By errorEnterPassword = By.xpath("//h2[text()='Please enter password']");
    public static By errorEnterValidEmail = By.xpath("//h2[text()='Please enter a valid email']");
    public static By rememberMeCheckboxOnLoginPage = By.name("rememberMe");
    public static By LogInOnLoginPage = By.xpath("//div[@title='Log In']");
    //Forget password page
    public static By emailFieldOnforgetPasswordPage =By.xpath("(//input[@type='email'])[2]");
    public static By proceedOnforgetPasswordPage =By.xpath("//button[contains(.,'Proceed')]");
    public static By errorEnterValidEmailOnforgetPasswordPage = By.xpath("//h2[text()='Please enter a valid email']");
    public static By errorEnterEmailOnforgetPasswordPage =By.xpath("//h2[text()='Please enter email']");
    //Sign up Page locators
    public static By emailFieldOnSignUpPage =By.xpath("(//input[@type='email'])[2]");
    public static By termsCheckboxOnSignUpPage = By.xpath("//span[@class='slds-checkbox_faux']");
    public static By logInOnSignUpPage = By.xpath("//a[text()='Log In']");
    public static By proceedOnSignUpPage =By.xpath("//button[contains(.,'Proceed')]");
    public static By errorEnterEmailOnSignUpPage =By.xpath("//h2[text()='Please enter email']");
    public static By errorchecktermsOnSignUpPage =By.xpath("//h2[text()='Please agree to the terms and conditions']");
    public static By errorEnterValidEmailOnSignUpPage =By.xpath("//h2[text()='Please enter a valid email']");
}
